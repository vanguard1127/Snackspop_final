//
//  HelperSubViewController.h
//  snackspopnew
//
//  Created by Admin on 2019-04-05.
//  Copyright © 2019 TestDemo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HelperView1.h"
#import "HelperView2.h"
NS_ASSUME_NONNULL_BEGIN

@interface HelperSubViewController : UIViewController

@property (assign, nonatomic)  NSInteger pageIndex;

@end

NS_ASSUME_NONNULL_END
