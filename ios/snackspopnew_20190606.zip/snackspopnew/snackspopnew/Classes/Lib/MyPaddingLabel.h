//
//  MyPaddingLabel.h
//  snackspopnew
//
//  Created by Admin on 2019-04-16.
//  Copyright © 2019 TestDemo. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MyPaddingLabel : UILabel

@end

NS_ASSUME_NONNULL_END
