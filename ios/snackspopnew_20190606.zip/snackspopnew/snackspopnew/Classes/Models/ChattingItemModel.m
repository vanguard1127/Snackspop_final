//
//  ChattingItemModel.m
//  snackspopnew
//
//  Created by Admin on 2019-04-10.
//  Copyright © 2019 TestDemo. All rights reserved.
//

#import "ChattingItemModel.h"

@implementation ChattingItemModel

@end
