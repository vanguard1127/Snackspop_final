//
//  ChatItemModel.m
//  snackspopnew
//
//  Created by Admin on 2019-04-09.
//  Copyright © 2019 TestDemo. All rights reserved.
//

#import "ChatItemModel.h"

@implementation ChatItemModel

@end
