//
//  SubAboutUsView.h
//  snackspopnew
//
//  Created by Admin on 2019-04-10.
//  Copyright © 2019 TestDemo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "../Utils/AppUtils.h"
NS_ASSUME_NONNULL_BEGIN

@interface SubAboutUsView : UIView
@property (weak, nonatomic) IBOutlet UIWebView* mWebView;
@end

NS_ASSUME_NONNULL_END
